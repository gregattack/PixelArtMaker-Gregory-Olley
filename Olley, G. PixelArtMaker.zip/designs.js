//Pixel Art Maker

/*Set up variables to refer to the 'submit' button and HTML element
in which the table will be added.*/
var canvas = document.getElementById("pixelCanvas");
const submiter = document.querySelector("#submitButton");

//Add event listener for the 'submit' button and trigger the 'makeGrid' function.
submiter.addEventListener('click', function makeGrid(event, height, width) {
event.preventDefault();

//I used the following commented out code to check the value that colorPicker was returning.
// console.log(document.getElementById("colorPicker").value);
var chooseColor = document.getElementById("colorPicker").value;

//Refer to the inputHeight and inputWidth ID's in the HTML.
var height = document.getElementById("inputHeight").value;
var width = document.getElementById("inputWidth").value;

//Reset the table to ensure no overlap.
canvas.innerHTML = null;

/*Nested loop that creates rows as referenced in 'height' and for each row, runs
a loop that creates the amount of columns referenced in 'width'*/
for (var _M_ = 0; _M_ < height; _M_++) {
  var row = canvas.insertRow(_M_);

  for (var _N_ = 0; _N_ < width; _N_++) {
    var column = row.insertCell(_N_);

/*In each cell adds an event listener that changes the style property when
clicked or double clicked*/
    var color = chooseColor
    column.addEventListener('click', function(evt){
      evt.target.style.backgroundColor = color
      console.log(color);
    })
    column.addEventListener('dblclick', function(evt){
      evt.target.style.backgroundColor = '#ffffff'
    })
}
}
});
